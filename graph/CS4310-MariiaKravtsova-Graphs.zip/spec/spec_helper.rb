require_relative '../MyEdge'
require_relative '../MyVertex'
require_relative '../MyGraph'

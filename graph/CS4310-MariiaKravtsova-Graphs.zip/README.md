# Undirected Graph, Assignment 2 CS4310
Author: Mariia Kravtsova
Date: February 2, 2017


#References

1. https://ruby-doc.org/core-2.2.0/Array.html
2. https://launchschool.com/books/ruby/read/arrays
3. http://billleidy.com/blog/advent-of-code-and-graph-data-structure.html
4. https://www.khanacademy.org/computing/computer-science/algorithms/graph-representation/a/describing-graphs
5. https://ex0ns.me/2015/01/30/-ruby-graph-representation/
6. http://stackoverflow.com/questions/3482125/ruby-element-present-in-array-or-not
7. http://stackoverflow.com/questions/2381163/ruby-array-find-first-object
8. http://stackoverflow.com/questions/21625992/syntax-error-unexpected-tivar-expecting
9. https://docs.ruby-lang.org/en/2.0.0/Array.html

Some of these references weren't very helpful, but I still kept them because they forced me to learn the ruby way, so I could just understand their code.

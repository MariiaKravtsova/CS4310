Class: CS 4310
Assignment: Huffman
Author: Mariia Kravtsova

To use:
please install the algorithms, you can use the included Gemfile with bundle install

Note:
* Included is also my testing file MyHuffman_test.rb just for more visual references
  and tests of the data structures.
* I realize the number or tests do not satisfy the requirements, but I was having some
  issues with creating Nodes in the spec file

Resources:
Binary Search Tree - http://rubyalgorithms.com/binary_search_tree.html
Min Heap - http://www.rubydoc.info/github/kanwei/algorithms/Containers/MinHeap
Algorithms - https://github.com/kanwei/algorithms
Huffman coding explaination + example - https://www.youtube.com/watch?v=ZdooBTdW5bM

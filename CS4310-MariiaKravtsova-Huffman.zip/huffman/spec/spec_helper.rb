require_relative '../MyHuffman'
